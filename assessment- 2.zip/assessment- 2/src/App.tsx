import Dashboard from "./dashboard";

function App() {
  return <Dashboard />;
}

export default App;
