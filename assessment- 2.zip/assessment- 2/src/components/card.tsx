import { FunctionComponent } from "react";

const Card: FunctionComponent<{
  title: string;
  imageSrc: string;
  owner: string;
  mintAddress: string;
  tokenAddress: string;
}> = ({ title, imageSrc, owner, mintAddress, tokenAddress }: any) => {
  return (
    <div className="rounded-xl bg-background [backdrop-filter:blur(40px)] flex flex-col p-3 items-start justify-start gap-[18px]">
      <div className="w-[364px] flex flex-row py-1 px-2 box-border items-start justify-between">
        <div className="text-white relative leading-[24px]">{title}</div>
        <img
          className="relative w-6 h-6 overflow-hidden shrink-0"
          alt=""
          src="/more-options.svg"
          style={{ cursor: "pointer" }}
        />
      </div>
      <div className="relative rounded-xl w-[364px] h-[364px] overflow-hidden shrink-0">
        <img
          className="absolute top-[0px] left-[0px] w-[364px] h-[364px] object-cover"
          alt=""
          src={imageSrc}
        />
      </div>
      <div className="rounded-xl bg-grey-level-3 w-[364px] overflow-hidden flex flex-col pt-2 px-2 pb-5 box-border items-center justify-end gap-[12px] text-sm">
        <div className="self-stretch rounded-lg bg-grey-level-1 flex flex-row py-2 pr-3 pl-2.5 items-center justify-between">
          <div className="text-white relative tracking-[0.03em] leading-[20px]">
            Owner
          </div>
          <div className="flex flex-row items-center justify-center gap-[12px]">
            <div className="relative box-border w-[0.5px] h-[12.5px] opacity-[0.2] border-r-[0.5px] border-solid border-primary-text-selection" />
            <div className="opacity-50 text-white text-sm font-normal font-['SF Pro Text'] leading-tight tracking-wide">
              {`${owner.substring(0, 5)}...${owner.substring(
                owner.length - 3
              )}`}
            </div>
          </div>
        </div>
        <div className="self-stretch rounded-lg bg-grey-level-1 flex flex-row py-2 pr-3 pl-2.5 items-center justify-between">
          <div className="text-white relative tracking-[0.03em] leading-[20px]">
            Mint address
          </div>
          <div className="flex flex-row items-center justify-center gap-[12px]">
            <div className="relative box-border w-[0.5px] h-[12.5px] opacity-[0.2] border-r-[0.5px] border-solid border-primary-text-selection" />
            <div className=" opacity-50 text-white text-sm font-normal font-['SF Pro Text']  ">
              {`${mintAddress.substring(0, 5)}...${mintAddress.substring(
                mintAddress.length - 3
              )}`}
            </div>
          </div>
        </div>
        <div className="self-stretch rounded-lg bg-grey-level-1 flex flex-row py-2 pr-3 pl-2.5 items-center justify-between">
          <div className="text-white relative tracking-[0.03em] leading-[20px]">
            Token address
          </div>
          <div className="flex flex-row items-center justify-center gap-[12px]">
            <div className="relative box-border w-[0.5px] h-[12.5px] opacity-[0.2] border-r-[0.5px] border-solid border-primary-text-selection" />
            <div className="opacity-50 text-white text-sm font-normal font-['SF Pro Text'] leading-tight tracking-wide">
              {`${tokenAddress.substring(0, 5)}...${tokenAddress.substring(
                tokenAddress.length - 3
              )}`}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;
