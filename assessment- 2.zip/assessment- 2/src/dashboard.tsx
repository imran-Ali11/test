import { FunctionComponent, useCallback } from "react";
import Card from "./components/card";
import { useState, useEffect } from "react";
import { Metaplex } from "@metaplex-foundation/js";
import { clusterApiUrl, Connection, PublicKey } from "@solana/web3.js";

const connection = new Connection(clusterApiUrl("devnet"));
const mx = Metaplex.make(connection);

const Dashboard: FunctionComponent = () => {
  const onBackIconClick = useCallback(() => {
    // Please sync "Dashboard" to the project
  }, []);

  const onForwardIconClick = useCallback(() => {
    // Please sync "Dashboard" to the project
  }, []);

  const cardData = [
    {
      title: "Cyberlinx #2551",
      imageSrc: "/4a9mo9lywx16j9khv2m74gllz6wwlkfmrm6ic40zkq-1@2x.png",
      owner: "72UGr...YdD",
      mintAddress: "72UGr...YdD",
      tokenAddress: "72UGr...YdD",
    },
    {
      title: "Cyberlinx #2551",
      imageSrc: "/4a9mo9lywx16j9khv2m74gllz6wwlkfmrm6ic40zkq-1@2x.png",
      owner: "72UGr...YdD",
      mintAddress: "72UGr...YdD",
      tokenAddress: "72UGr...YdD",
    },
    {
      title: "Cyberlinx #2551",
      imageSrc: "/4a9mo9lywx16j9khv2m74gllz6wwlkfmrm6ic40zkq-1@2x.png",
      owner: "72UGr...YdD",
      mintAddress: "72UGr...YdD",
      tokenAddress: "72UGr...YdD",
    },
  ];

  const [loading, setLoading] = useState(false);
  const [nfts, setNfts] = useState<any>(null);
  const ownerPublicKey = new PublicKey(
    "3ijFZcJKmp1EnDbbuaumWYvEFbztx9NRupwTXTchK9bP"
  );

  // Assuming this is an asynchronous function
  const fetchData = async () => {
    const nftsData = await mx.nfts().findAllByOwner({
      owner: ownerPublicKey,
    });

    // Create an array of promises for fetching the data
    const fetchPromises = nftsData.map(async (nft) => {
      const response = await fetch(nft.uri);
      const json = await response.json();
      return { ...nft, image: json.image }; // Add the image property to the nft object
    });

    // Wait for all promises to resolve
    const updatedNfts = await Promise.all(fetchPromises);

  
    setNfts(updatedNfts); // Update the state with the modified nfts array
  };
  useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    <>loading...</>;
  }
  return (
    <div className="relative bg-background w-full h-[1006px] overflow-hidden text-left text-[28px] text-primary-text-selection font-sf-pro-text">
      <div className="absolute top-[0px] left-[108px] rounded-tl-13xl rounded-tr-none rounded-br-none rounded-bl-13xl bg-gray w-full h-full">
        <div className=" absolute top-[80px] left-[1px] w-[1331px] flex flex-row py-5 px-16 box-border items-center justify-between text-center">
          <div className="relative leading-[32px] font-medium">Dashboard</div>
          <div className="rounded-sm bg-grey-level-1 w-10 h-10 flex flex-col p-2.5 box-border items-center justify-center">
            <img
              className="relative w-6 h-6 overflow-hidden shrink-0"
              alt=""
              src="/refresh-icon.svg"
              onClick={fetchData}
              style={{cursor:'pointer'}}
            />
          </div>
        </div>
        <div className="absolute top-[0px] left-[0px] w-[1332px] flex flex-row py-5 px-16 box-border items-center justify-between text-sm">
          <div className="rounded-sm bg-grey-level-3 h-10 flex flex-row py-[3px] px-3 box-border items-center justify-start gap-[8px]">
            <div className="rounded-9981xl bg-whitesmoke w-6 h-6 flex flex-row py-1 px-[9px] box-border items-center justify-center">
              <img
                className="relative w-[14.74px] h-6"
                alt=""
                src="/group-185.svg"
              />
            </div>
            <div className="relative leading-[20px]">ETH/USDT</div>
            <div className="relative leading-[20px] text-success">
              1137.62 +2.62%↑
            </div>
          </div>
          <div className="rounded-sm bg-grey-level-3 h-10 flex flex-row py-[3px] px-3 box-border items-center justify-start gap-[12px]">
            <img
              className="relative rounded-[1000px] w-6 h-6 overflow-hidden shrink-0 object-cover"
              alt=""
              src="/avatar@2x.png"
            />
            <div className="relative leading-[20px]">zash</div>
            <div className="relative box-border w-px h-3 opacity-[0.2] border-r-[1px] border-solid border-primary-text-selection" />
            <div className="relative leading-[20px]">User ID: 11026666</div>
          </div>
        </div>
        <div className="absolute top-[0px] left-[-108px] [backdrop-filter:blur(20px)] w-[108px] h-[1006px] flex flex-col pt-6 px-0 pb-9 box-border items-center justify-between">
          <img
            className="relative w-[46px] h-16 object-cover"
            alt=""
            src="/asset-38-1@2x.svg"
          />
          <div className="self-stretch flex flex-col items-start justify-start">
            <div className="rounded-xl w-[108px] flex flex-col py-8 px-5 box-border items-center justify-center">
              <img
                className="relative w-6 h-6 overflow-hidden shrink-0"
                alt=""
                src="/home.svg"
              />
            </div>
            <div className="rounded-xl w-[108px] flex flex-col py-8 px-5 box-border items-center justify-center">
              <img className="relative w-6 h-6" alt="" src="/listing.svg" />
            </div>
            <div className="rounded-xl w-[108px] flex flex-col py-8 px-5 box-border items-center justify-center">
              <img className="relative w-6 h-6" alt="" src="/settings.svg" />
            </div>
          </div>
          <div className="flex flex-col items-start justify-start">
            <div className="rounded-xl w-[104px] flex flex-col py-8 px-5 box-border items-center justify-center relative gap-[2px]">
              <img
                className="relative w-6 h-6 overflow-hidden shrink-0 z-[0]"
                alt=""
                src="/bell.svg"
              />
              <div className="absolute my-0 mx-[!important] h-[12.5%] w-[10.58%] top-[36.36%] right-[38.46%] bottom-[51.14%] left-[50.96%] rounded-[50%] bg-primary-text-selection box-border z-[1] border-[2px] border-solid border-background" />
            </div>
          </div>
        </div>
        <div className="absolute top-[180px] left-[51px] flex flex-row items-start justify-start gap-[33px] text-base ">
          {nfts &&
            nfts.map((nft: any, index: any) => (
              <Card
                key={index}
                title={nft.name}
                imageSrc={nft.image}
                owner={nft.updateAuthorityAddress.toBase58()}
                mintAddress={nft.mintAddress.toBase58()}
                tokenAddress={nft.mintAddress.toBase58()}
              />
            ))}
        </div>
        <div className="absolute top-[820px] left-[518px] rounded-[39px] bg-background flex flex-col p-[11px] items-start justify-start">
          <div className="flex flex-row items-start justify-start gap-[161px]">
            <img
              className="relative w-14 h-14 cursor-pointer"
              alt=""
              src="/back-icon.svg"
              onClick={onBackIconClick}
            />
            <img
              className="relative w-14 h-14 cursor-pointer"
              alt=""
              src="/forward-icon.svg"
              onClick={onForwardIconClick}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
