/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: "#000",
        gray: "#282a31",
        "grey-level-3": "#18191d",
        "grey-level-1": "#131417",
        "primary-text-selection": "#fff",
        "unselected-state": "#666",
        base: "#22272f",
        success: "#0ac18e",
        whitesmoke: "#eceff0",
      },
      spacing: {},
      fontFamily: {
        "sf-pro-text": "'SF Pro Text'",
      },
      borderRadius: {
        "13xl": "32px",
        xl: "20px",
        sm: "14px",
        "9981xl": "10000px",
      },
    },
    fontSize: {
      sm: "14px",
      base: "16px",
      inherit: "inherit",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
